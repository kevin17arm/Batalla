/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package batalla;
import java.util.Random;
/**
 *
 * @author Personal
 */
// Clase abstracta que sirve como base para cualquier personaje de combate
public abstract class Personaje {
    String nombre;          // Nombre del personaje
    int vida;               // Puntos de vida
    int maxDanio;           // Daño máximo que puede causar
    int evasion;            // Probabilidad de evadir ataques (en %)
    boolean saltaTurno = false; // Si debe omitir su próximo turno
    static final Random random = new Random();

    // Constructor para inicializar las características del personaje
    public Personaje(String nombre, int vida, int maxDanio, int evasion) {
        this.nombre = nombre;
        this.vida = vida;
        this.maxDanio = maxDanio;
        this.evasion = evasion;
    }

    // Determina si el personaje puede actuar este turno
    public boolean puedeActuar() {
        if (saltaTurno) {
            saltaTurno = false;
            return false;
        }
        return true;
    }

    // Determina aleatoriamente si el personaje evade un ataque
    public boolean esquivaAtaque() {
        return random.nextInt(100) < evasion;
    }

    // Ataca a otro personaje. Devuelve el daño infligido (0 si fue evadido)
    public int atacar(Personaje objetivo) {
        int danio = random.nextInt(maxDanio - 9) + 10;
        if (!objetivo.esquivaAtaque()) {
            objetivo.recibirDanio(danio);
        } else {
            danio = 0;
        }
        if (danio == maxDanio) {
            objetivo.saltaTurno = true; // Golpe crítico: el oponente pierde un turno
        }
        return danio;
    }

    // Reduce los puntos de vida del personaje
    public void recibirDanio(int danio) {
        vida -= danio;
    }

    // Verifica si el personaje sigue con vida
    public boolean estaVivo() {
        return vida > 0;
    }

    // Obtiene la vida actual (no puede ser negativa)
    public int getVida() {
        return Math.max(vida, 0);
    }

    // Devuelve el nombre del personaje
    public String getNombre() {
        return nombre;
    }
}