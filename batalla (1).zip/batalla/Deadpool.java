/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package batalla;

/**
 *
 * @author Personal
 */
// Subclase de Personaje que representa al personaje Deadpool
public class Deadpool extends Personaje {
    public Deadpool(int vida) {
        super("Deadpool", vida, 100, 25); // Daño máximo 100, evasión 25%
    }
}
