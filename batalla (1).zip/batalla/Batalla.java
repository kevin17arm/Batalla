/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package batalla;

/**
 *
 * @author Personal
 */
// Clase principal que simula la batalla por turnos entre Deadpool y Wolverine
public class Batalla {

    public static void main(String[] args) throws InterruptedException {
        java.util.Scanner sc = new java.util.Scanner(System.in);

        // Ingreso de vida inicial para cada personaje
        System.out.print("Vida inicial de Deadpool: ");
        int vidaDeadpool = sc.nextInt();
        System.out.print("Vida inicial de Wolverine: ");
        int vidaWolverine = sc.nextInt();

        // Se crean los objetos con sus valores iniciales
        Personaje deadpool = new Deadpool(vidaDeadpool);
        Personaje wolverine = new Wolverine(vidaWolverine);

        int turno = 1;

        // Bucle de combate hasta que uno pierda
        while (deadpool.estaVivo() && wolverine.estaVivo()) {
            System.out.println("\n--- Turno " + turno + " ---");

            // Turno de Deadpool
            if (deadpool.puedeActuar()) {
                int danio = deadpool.atacar(wolverine);
                if (danio > 0) {
                    System.out.println(deadpool.getNombre() + " ataca con " + danio + " de daño");
                    if (danio == 100) System.out.println("¡Golpe crítico! Wolverine pierde su siguiente turno.");
                } else {
                    System.out.println("Wolverine esquivó el ataque de Deadpool");
                }
            } else {
                System.out.println("Deadpool se recupera y no ataca este turno.");
            }

            // Verifica si Wolverine fue derrotado antes de su turno
            if (!wolverine.estaVivo()) break;

            Thread.sleep(1000); // Pausa para dar dramatismo

            // Turno de Wolverine
            if (wolverine.puedeActuar()) {
                int danio = wolverine.atacar(deadpool);
                if (danio > 0) {
                    System.out.println(wolverine.getNombre() + " ataca con " + danio + " de daño");
                    if (danio == 120) System.out.println("¡Golpe crítico! Deadpool pierde su siguiente turno.");
                } else {
                    System.out.println("Deadpool esquivó el ataque de Wolverine");
                }
            } else {
                System.out.println("Wolverine se recupera y no ataca este turno.");
            }

            // Mostrar estado de vida actual
            System.out.println("Vida de Deadpool: " + deadpool.getVida());
            System.out.println("Vida de Wolverine: " + wolverine.getVida());

            Thread.sleep(1000);
            turno++;
        }

        // Resultado final
        System.out.println("\n--- ¡La batalla ha terminado! ---");
        if (deadpool.estaVivo()) {
            System.out.println("Deadpool es el ganador ");
        } else {
            System.out.println("Wolverine es el ganador ");
        }
    }
}